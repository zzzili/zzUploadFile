﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace TestUploadFile.Controllers
{
    /// <summary>
    /// upload 的摘要说明
    /// </summary>
    public class upload : IHttpHandler
    {
        private static string _filedir = ConfigurationManager.AppSettings["SavePath"];
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            try
            {
                string result = UploadImg(context);   //图片上传
                context.Response.Write(result);
            }
            catch(Exception ex)
            {
                context.Response.Write("Error:"+ex.Message);//文件上传失败   
            }
        }

        /// <summary>   
        /// 图片上传   
        /// </summary>   
        /// <param name="context"></param>   
        /// <returns></returns>   
        private string UploadImg(HttpContext context)
        {
            string date = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString();

            int cout = context.Request.Files.Count;
            if (cout > 0)
            {
                HttpPostedFile hpf = context.Request.Files[0];
                if (hpf != null)
                {
                    string fileExt = Path.GetExtension(hpf.FileName).ToLower();
                    //只能上传文件，过滤不可上传的文件类型     

                    //string fileFilt = ".gif|.jpg|.bmp|.jpeg|.png";
                    //if (fileFilt.IndexOf(fileExt) <= -1)
                    //{
                    //    return "1";
                    //}

                    //判断文件大小     
                    int length = hpf.ContentLength;
                    if (length > 16240000)
                    {
                        return "2";
                    }

                    Random rd = new Random();
                    DateTime nowTime = DateTime.Now;
                    string newFileName = nowTime.Year.ToString() + nowTime.Month.ToString() + nowTime.Day.ToString() + nowTime.Hour.ToString() + nowTime.Minute.ToString() + nowTime.Second.ToString() + rd.Next(1000, 1000000) + Path.GetExtension(hpf.FileName);
                    if (!Directory.Exists(_filedir))
                    {
                        Directory.CreateDirectory(_filedir);
                    }
                    string fileName = _filedir + newFileName;
                    hpf.SaveAs(fileName);
                    return newFileName;
                }
            }
            return "3";
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}